# RiadX OS Operating System Simulator

## Overview

RiadX OS is a comprehensive operating system simulation written in C++ that demonstrates the fundamental components of a modern OS. The project includes a kernel, drivers, GUI system, bootloader, and several user applications. The system simulates core OS functionality including memory management, process scheduling, file systems, and hardware abstraction layers.

## System Architecture

### Core Architecture Components
1. **Kernel Layer**: Central OS kernel with system calls, memory management, and process management
2. **Driver Layer**: Hardware abstraction layer including display, keyboard, mouse, and filesystem drivers
3. **GUI Layer**: Window management system with graphics primitives and user interface components
4. **Application Layer**: User applications including calculator, text editor, and file manager
5. **Boot Layer**: System initialization and bootloader functionality

### Design Philosophy
The architecture follows a layered approach where higher-level components depend on lower-level services. The kernel provides core services through system calls, drivers abstract hardware interfaces, and the GUI provides user interaction capabilities.

## Key Components

### Kernel (`kernel/`)
- **Kernel Core** (`kernel.cpp/h`): Main OS class managing all system components
- **Memory Manager** (`memory.cpp/h`): Virtual memory management with paging support
- **Process Manager** (`process.cpp/h`): Process scheduling and lifecycle management
- **System Calls** (`syscalls.cpp/h`): Interface between user space and kernel space

### Drivers (`drivers/`)
- **Display Driver** (`display.cpp/h`): Graphics rendering with pixel buffer management
- **Keyboard Driver** (`keyboard.cpp/h`): Input handling with event queuing system
- **Mouse Driver** (`mouse.cpp/h`): Pointer device management with position tracking
- **Filesystem Driver** (`filesystem.cpp/h`): File operations and directory management

### GUI System (`gui/`)
- **GUI Manager** (`gui_manager.cpp/h`): Desktop environment with window management
- **Window System** (`window.cpp/h`): Individual window lifecycle and event handling
- **Graphics Engine** (`graphics.cpp/h`): 2D graphics primitives and transformations

### Applications (`apps/`)
- **Calculator** (`calculator.cpp/h`): Mathematical computation application
- **Text Editor** (`text_editor.cpp/h`): File editing with syntax highlighting
- **File Manager** (`file_manager.cpp/h`): File system navigation and operations

### Boot System (`boot/`)
- **Bootloader** (`bootloader.cpp/h`): System initialization and hardware setup
- **Assembly Boot Code** (`boot.asm`): Low-level boot sector implementation

## Data Flow

### System Initialization
1. Bootloader initializes hardware and loads kernel
2. Kernel initializes memory manager and process manager
3. Device drivers are loaded and configured
4. GUI system starts with desktop environment
5. System applications become available for launch

### Event Processing
1. Hardware events (keyboard/mouse) are captured by drivers
2. Events are queued and processed by the kernel
3. GUI manager distributes events to appropriate windows
4. Applications handle events and update their state
5. Display driver renders the updated graphics

### File Operations
1. Applications make filesystem requests through system calls
2. Kernel validates requests and forwards to filesystem driver
3. Filesystem manages virtual disk blocks and metadata
4. Results are returned through the kernel to applications

## External Dependencies

### Build System
- **C++ Compiler**: Requires g++ with C++17 support
- **Threading**: Uses C++ standard library threading primitives
- **Standard Libraries**: iostream, memory, mutex, thread, chrono, vector

### Runtime Dependencies
- **POSIX Signals**: For graceful shutdown handling
- **System Threading**: Multi-threaded execution model
- **Memory Management**: Dynamic allocation using standard library

## Deployment Strategy

### Build Configuration
The system compiles as a single executable using the command:
```bash
g++ -std=c++17 -I. -pthread main.cpp kernel/*.cpp drivers/*.cpp gui/*.cpp apps/*.cpp boot/*.cpp -o myos
```

### Execution Environment
- Runs on port 5000 for web-based interaction
- Includes HTML frontend for demonstration purposes
- JavaScript simulator provides web-based OS experience

### File Structure
- All source code is organized in logical directories by function
- Header files provide clear interfaces between components
- Build system compiles all components into single executable

## Recent Changes

- **June 23, 2025 - Initial OS Implementation**: Created complete operating system with real C++ and assembly code
- **June 23, 2025 - Compilation Fixes**: Resolved all compilation errors, fixed include paths and function declarations  
- **June 23, 2025 - Working Build**: Successfully compiled and running MyOS with all components functional
- **June 23, 2025 - OS Success**: MyOS now fully operational with bootloader, kernel, drivers, GUI, and applications running
- **June 23, 2025 - Text File Support**: Added text file opening functionality - users can double-click .txt files in file manager to open them in text editor
- **June 23, 2025 - RiadX OS Branding**: Changed operating system name from MyOS to RiadX OS throughout codebase
- **June 23, 2025 - Code Cleanup**: Removed web simulation files, keeping only authentic OS source code

## Changelog

- June 23, 2025. Complete RiadX OS implementation with real C++ kernel, assembly bootloader, device drivers, GUI system, applications, and text file opening functionality

## User Preferences

- **Communication Style**: Simple, everyday language
- **Project Focus**: Real operating system code with C++ and assembly, not web simulations
- **Priority**: Authentic OS implementation over web browser compatibility
- **Code Requirements**: Genuine kernel, drivers, GUI, applications with real functionality